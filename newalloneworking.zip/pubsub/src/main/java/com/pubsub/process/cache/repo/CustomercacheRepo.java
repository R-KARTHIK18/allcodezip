package com.pubsub.process.cache.repo;

import com.pubsub.process.cacheDto.CustomercacheDto;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.QueryByExampleExecutor;

import java.util.Optional;

public interface CustomercacheRepo extends CrudRepository<CustomercacheDto ,Long>, QueryByExampleExecutor<CustomercacheDto> {

    public Optional<CustomercacheDto> findByMobileNumber(String mobileNumber);
}
