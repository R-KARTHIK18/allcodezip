package com.pubsub.process.controller;

import com.pubsub.process.entity.Customer;
import com.pubsub.process.entity.Users;

import com.pubsub.process.model.customerDto;
import com.pubsub.process.service.CustomerServiceimpl;
import com.pubsub.process.service.EnrollService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class EnrollContorller {
    @Autowired
    private EnrollService service;

    @Autowired
    private CustomerServiceimpl customerServiceimpl;
    @PostMapping("/register")
    public Users register(@RequestBody Users user){
        return  service.register(user);
    }

    @GetMapping("/generatetoken")
    //1
    public String getgreet(@RequestBody Users user){
        return  service.verifyuser(user);
    }
    @GetMapping("/validate")
    public  String test() {
        return "test";
    }

    @PostMapping("/saveCustomer")
    public customerDto saveCustomer(@RequestBody customerDto request){

    return  customerServiceimpl.savecustomer(request);
    }

    @GetMapping("/getcustomer")
    public customerDto getcustomer(@RequestParam String mdn){

    return  customerServiceimpl.findcustomer(mdn);
    }
}


