package com.pubsub.process.service;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.cloud.spring.pubsub.core.PubSubTemplate;
import com.google.cloud.spring.pubsub.integration.AckMode;
import com.google.cloud.spring.pubsub.integration.inbound.PubSubInboundChannelAdapter;
import com.google.cloud.spring.pubsub.integration.outbound.PubSubMessageHandler;
import com.google.cloud.spring.pubsub.support.BasicAcknowledgeablePubsubMessage;
import com.google.cloud.spring.pubsub.support.GcpPubSubHeaders;
import com.pubsub.process.entity.Customer;
import com.pubsub.process.entity.Users;
import com.pubsub.process.repo.Customerrepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.annotation.MessagingGateway;

import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.Collections;


@Configuration

public class pubsubsender {

    @Autowired
    ObjectMapper objectMapper;

    @Autowired
    Customerrepo customerrepo;


    @MessagingGateway(name = "myPubSubGateway",defaultRequestChannel = "outboundmsgchannel")
    public interface Outboundchannel {
        //4
        void sendtoPubsub(String msg);

    }

    //5
    @Bean
    @ServiceActivator(inputChannel = "outboundmsgchannel")
    public PubSubMessageHandler messagesend(PubSubTemplate pubSubTemplate) {
        return new PubSubMessageHandler(pubSubTemplate, "ayhtin");
    }


//6. create channel

    @Bean
    MessageChannel pubsubInputChannel() { return new DirectChannel(); }

    @Bean
    MessageChannel outboundmsgchannel() { return new DirectChannel(); }
    // 7 create recevicer adapter

@Bean
    public PubSubInboundChannelAdapter inboundChannelAdapter(
            @Qualifier("pubsubInputChannel") MessageChannel messageChannel,
            PubSubTemplate pubSubTemplate){
        PubSubInboundChannelAdapter adapter=new PubSubInboundChannelAdapter(pubSubTemplate,"ayhtin-sub");
        adapter.setOutputChannel(messageChannel);
    adapter.setAckMode(AckMode.MANUAL);
    adapter.setErrorChannelName("handleerrors");
         return adapter;

    }

    //msg recevier

    @ServiceActivator(inputChannel = "pubsubInputChannel")
    public void messageReceiver(
            String payload,
            @Header (GcpPubSubHeaders.ORIGINAL_MESSAGE) BasicAcknowledgeablePubsubMessage message) throws JsonProcessingException {
        String messageId =message.getPubsubMessage().getMessageId();
        Customer savecustomer = objectMapper.readValue(payload, Customer.class);
        System.out.println("logssssss  --  :"+payload);

        Customer res=customerrepo.save(savecustomer);



    }


//    @ServiceActivator(inputChannel =  "handleerrors")
//    public void pubsubErrorHandler(Message<MessagingException> exceptionMessage) {
//        System.out.println("This message will be automatically acked because error handler completes successfully");
//        BasicAcknowledgeablePubsubMessage originalMessage =
//                (BasicAcknowledgeablePubsubMessage)exceptionMessage.getPayload().getFailedMessage()
//                        .getHeaders().get(GcpPubSubHeaders.ORIGINAL_MESSAGE);
//        System.out.println("PubSub Error: " + originalMessage.getPubsubMessage());
//    }

    public static class userPrinciple implements UserDetails {

        private Users user;



        public userPrinciple(Users user){
            this.user=user;
        }
        @Override
        public Collection<? extends GrantedAuthority> getAuthorities() {
            return Collections.singleton(new SimpleGrantedAuthority("USER"));
        }

        @Override
        public String getPassword() {
            return user.getPassword();
        }

        @Override
        public String getUsername() {
            return user.getName();
        }
        @Override
        public boolean isAccountNonExpired() {
            return UserDetails.super.isAccountNonExpired();
        }

        @Override
        public boolean isAccountNonLocked() {
            return UserDetails.super.isAccountNonLocked();
        }

        @Override
        public boolean isCredentialsNonExpired() {
            return UserDetails.super.isCredentialsNonExpired();
        }

        @Override
        public boolean isEnabled() {
            return UserDetails.super.isEnabled();
        }


    }
}
