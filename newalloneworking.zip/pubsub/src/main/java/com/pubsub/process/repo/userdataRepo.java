package com.pubsub.process.repo;

import com.pubsub.process.entity.Users;
import org.springframework.data.jpa.repository.JpaRepository;

public interface userdataRepo extends JpaRepository<Users,Integer> {
    Users findByName(String username);
}
