package com.pubsub.process.config;


import java.time.LocalDate;
import java.util.Optional;


import com.pubsub.process.entity.Rediscount;


import com.pubsub.process.entity.Customer;
import com.pubsub.process.repo.Customerrepo;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;



import lombok.extern.log4j.Log4j2;

import org.springframework.data.redis.core.RedisTemplate;

@Service
@Log4j2
public class customerCacheservice {

	@Autowired
	Customerrepo customerrepo;
	
    @Autowired
    ObjectMapper mapper;
    
    @Autowired
    private RedisTemplate  redisTemplate;
	
	public Customer getuCustomer(long id) throws JsonMappingException, JsonProcessingException {
			LocalDate currentDate=LocalDate.now();
		Optional<Customer> cus=customerrepo.findById(id);
		if(cus.isPresent()) {
			String  data = (String) redisTemplate.opsForHash().get("customer",currentDate.toString());
	 		if(null!=data  ) {
	 			log.info("RetryInstallcount  Data is not null ");
	 			Rediscount retryUninstall =	mapper.readValue(data, Rediscount.class);
	 			int count=retryUninstall.getCount(); 
	 			 log.info("Current RetryInstallcount for {}: {}", currentDate, count);
	 			retryUninstall.setCount(retryUninstall.getCount()+1 );
	 			String dataString = mapper.writeValueAsString(retryUninstall);
	 			 redisTemplate.opsForHash().put("customer",currentDate.toString(),dataString);
	 			 log.info("Updated RetryInstallcount data for {}: {}", currentDate, dataString);
	 		}else {
	 			log.info("RetryInstallcount  Data is  null ");
	 			String dataString = mapper.writeValueAsString(Rediscount.builder().count(1).build());
	 			 redisTemplate.opsForHash().put("customer",currentDate.toString(),dataString);
			}
		}
		return null;
		
	}

	public String savecustomer(Customer entity) {

		return null;
	}
	
}
