package com.pubsub.process.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.pubsub.process.cache.repo.CustomercacheRepo;
import com.pubsub.process.cacheDto.CustomercacheDto;
import com.pubsub.process.entity.Customer;
import com.pubsub.process.model.customerDto;
import com.pubsub.process.repo.Customerrepo;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.swing.text.html.Option;
import java.util.Optional;

@Service
@Log4j2
public class CustomerServiceimpl {

    @Autowired
    Customerrepo customerrepo;

    @Autowired
    ObjectMapper objectMapper;

    @Autowired
    CustomercacheRepo custcacherepo;
    @Autowired
    pubsubsender.Outboundchannel outboundchannel;
    public customerDto savecustomer( customerDto req){

        Customer savecustomer = objectMapper.convertValue(req, Customer.class);

        try {

            String custmsg = objectMapper.writeValueAsString(savecustomer);
            outboundchannel.sendtoPubsub(custmsg);
//            Customer res=customerrepo.save(savecustomer);
            return  req;
        }catch (Exception e){
            log.info("Exception occurred in Save customer api :{}",e.getMessage());
        }

        return  null;

    }

    public customerDto findcustomer(String mdn) {
        customerDto response=null;

        Optional<CustomercacheDto> customercacheres=custcacherepo.findByMobileNumber(mdn);
        
        if(customercacheres.isPresent()){
            return  customercacheres.get().getCustomerEntity();
        }else{

            Customer res=customerrepo.findByMobileNumber(mdn);
            
            response=objectMapper.convertValue(this, customerDto.class);
            pushtocache();
        }
        return response;
    }

    private void pushtocache() {
    }


}
