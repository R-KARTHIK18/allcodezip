package com.pubsub.process.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

import lombok.extern.log4j.Log4j2;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Log4j2
public class RedishContoller {


//    @Autowired
//    customerservice customerservice;

    @GetMapping("/getdata")
    public String getfromdbadnredis(@RequestParam(name = "id") long custid) throws JsonMappingException, JsonProcessingException {
        log.info("test");
//        customerservice.getuCustomer(custid);

        return null;
    }
}
