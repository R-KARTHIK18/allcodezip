package com.pubsub.process.config;



//import com.pubsub.process.service.myUserDetailsService;

import com.pubsub.process.service.myUserDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
public class SecurityConfig  {

// 6 for 7 will move to myUserDetailsService class
    @Autowired
    private myUserDetailsService userimpl;

    @Autowired
    private Jwtfilter jwtfilter;
    //3
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        // to disable the default security form spring security da
    return http.csrf(x->x.disable())
        // to achive the block of any request only access those are authorized
                        .authorizeHttpRequests(requst->
                                requst.requestMatchers("register","generatetoken")
                        .permitAll()
                        .anyRequest().authenticated())
                        .httpBasic(Customizer.withDefaults())
                        .sessionManagement(session->session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            // this filter check the user name and password authenticate filter before
//11 it will check with jwtfilter class we made

            .addFilterBefore(jwtfilter, UsernamePasswordAuthenticationFilter.class)
                        .build();
    //  20 once got verify with jwtfilter will return  verifyuser in enrollservices
    }

    // 4
    @Bean
    public AuthenticationProvider authenticationProvider(){
        DaoAuthenticationProvider provider=new DaoAuthenticationProvider();
//        provider.setPasswordEncoder(NoOpPasswordEncoder.getInstance());
        provider.setPasswordEncoder(new BCryptPasswordEncoder(12));
        //5  userimpl
        provider.setUserDetailsService(userimpl);
        //10 will return the authentication tru or false to securityFilterChain in this same class
        return  provider;
    }

// just a bean
    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration authConfig) throws Exception {
        return authConfig.getAuthenticationManager();
    }

}
