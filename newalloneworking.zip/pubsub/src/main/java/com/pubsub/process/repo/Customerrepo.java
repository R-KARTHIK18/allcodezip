package com.pubsub.process.repo;

import com.pubsub.process.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;



public interface Customerrepo extends JpaRepository<Customer, Long>{

    Customer findByMobileNumber(String username);
}
