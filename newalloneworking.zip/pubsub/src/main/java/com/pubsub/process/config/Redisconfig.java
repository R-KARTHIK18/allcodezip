package com.pubsub.process.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisPassword;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;

@Configuration
public class Redisconfig {

	
    @Value("${spring.redis.host}")
    private String redisHostName;

    @Value("${spring.redis.port}")
    private Integer redisPort;

    @Value("${spring.redis.password}")
    private String password;
    
    
    @Value("${spring.redis.username}")
    private String userName;
    @Value("${spring.redis.dbindex}")
    private Integer dbIndex;
	@Bean
	public JedisConnectionFactory redConnectionFactory() {
		
		RedisStandaloneConfiguration redisStandaloneConfiguration=new RedisStandaloneConfiguration(redisHostName,redisPort);
		redisStandaloneConfiguration.setPassword(RedisPassword.of(password));
		
		JedisConnectionFactory jedisConnectionFactory=new JedisConnectionFactory(redisStandaloneConfiguration);
		jedisConnectionFactory.afterPropertiesSet();
		
		return jedisConnectionFactory;
	}		
		@Bean
		public RedisTemplate<String,String> redisTemplate(){
			
			RedisTemplate<String,String> redisTemplate=new RedisTemplate<>();
			redisTemplate.setConnectionFactory(redConnectionFactory());
			
			redisTemplate.setKeySerializer(new StringRedisSerializer());
			redisTemplate.setValueSerializer(new StringRedisSerializer());
			
			redisTemplate.setHashKeySerializer(new StringRedisSerializer());
			redisTemplate.setHashValueSerializer(new StringRedisSerializer());
			
			redisTemplate.setEnableTransactionSupport(true);
			redisTemplate.afterPropertiesSet();
			
			return redisTemplate;
			
			
		
		
	}
	
	
	
	
}
