package com.pubsub.process.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.UpdateTimestamp;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class customerDto {

	private long id;

	private String name;

	private String email;

	private LocalDate dateOfBirth;

	private String gender;

	private String mobileNumber;

	private Boolean active;

	private LocalDateTime createdDate;

	private String createdBy;

	private LocalDateTime modifiedDate;


	private String modifiedBy;

}
