package com.pubsub.process.service;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.pubsub.process.entity.Users;
import com.pubsub.process.repo.Customerrepo;
import com.pubsub.process.repo.userdataRepo;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

//7
@Service
@Log4j2
public class myUserDetailsService implements UserDetailsService {

    @Autowired
    ObjectMapper mapper;
    @Autowired
    private userdataRepo userRepo;



//8
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Users customer=userRepo.findByName(username);
        if (customer == null) {
            throw new UsernameNotFoundException("User not found");
        }
        log.info("user data found {}",customer.getName());
        // 9 once the user found will retrun the useretails to security config class authenticationProvider method
        return new userPrinciple(customer);
    }
}
