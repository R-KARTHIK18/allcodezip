package com.pubsub.process.cacheDto;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.pubsub.process.model.customerDto;
import jakarta.persistence.Id;
import org.springframework.data.redis.core.index.Indexed;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class CustomercacheDto {

    private static final long serialVersionUID = 1L;

    @Id
    private long id;

    @Indexed
    private String mobileNumber;

    private String name;

    private String email;

    private LocalDate dateOfBirth;

    private String gender;



    private Boolean active;

    private LocalDateTime createdDate;

    private String createdBy;

    private LocalDateTime modifiedDate;


    private String modifiedBy;

    private static final ObjectMapper objectMapper = new ObjectMapper();
    public customerDto getCustomerEntity( ) {
        return objectMapper.convertValue(this, customerDto.class);

    }
}
