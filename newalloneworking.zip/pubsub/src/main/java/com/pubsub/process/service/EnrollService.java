package com.pubsub.process.service;

import com.pubsub.process.entity.Users;
import com.pubsub.process.repo.userdataRepo;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

@Service
@Log4j2

public class EnrollService {

    @Autowired
    private userdataRepo repo;

    @Autowired
    AuthenticationManager  authmanager;


    private String seckeys="";

    public  EnrollService(){
        try {
            KeyGenerator ke=KeyGenerator.getInstance("HmacSHA256");
            SecretKey sk=ke.generateKey();
            seckeys= Base64.getEncoder().encodeToString(sk.getEncoded());
        }catch (NoSuchAlgorithmException es){
        log.info(es.getMessage());
        }


    }
private BCryptPasswordEncoder encoder=new BCryptPasswordEncoder(12);
    public Users register(Users users) {

        try {
            users.setPassword(encoder.encode(users.getPassword()));
            users.setCreateddate(LocalDateTime.now());
              return  repo.save(users);
        }catch (Exception e){
            log.info(e.getMessage());
        }
    return null;
    }

    // 21 after veriy
    public String verifyuser(Users user) {

        try{
            //2 - 3 will move SecurityConfig class
        Authentication auth= authmanager.authenticate(new UsernamePasswordAuthenticationToken(user.getName(),user.getPassword()));
//22 if the user is autheorized will generate the token
       if (auth.isAuthenticated()){
           log.info("got auth token");
           return generatetoken(user.getName()) ;
       }else {return "fail";

       }}catch (Exception e){
            log.info(e.getMessage());
        }

    return  null;
    }

    //23     to generatet he token we need secrate key will get form the base64 decoder
    private String generatetoken(String name) {
        Map<String,Object> claims=new HashMap<>();

        return Jwts.builder()

                .claims()
                .add(claims).subject(name)
                .issuedAt(new Date(System.currentTimeMillis()))
                .expiration(new Date(System.currentTimeMillis()+60*60*30))
                .and()
                .signWith(getkey()).compact();
    }

    //13
    private SecretKey getkey() {
        byte[] keysby= Decoders.BASE64.decode(seckeys);
        return Keys.hmacShaKeyFor(keysby);
    }
    // 12.2
    public String extractuserName(String token) {

        return extractclaim(token, Claims::getSubject);
    }
// 12.3
    private <T> T extractclaim(String token, Function<Claims,T> claimResolver) {
        final Claims claims=extractAllclaim(token);
            return  claimResolver.apply(claims);
    }
    // 12.4
    private Claims extractAllclaim(String token) {
        return Jwts.parser()
                .verifyWith(getkey())
                .build().parseSignedClaims(token).getPayload();
    }

    // 16 will validate token and its expire time
    public boolean validateToken(String token, UserDetails userDetails) {

        final String userName=extractuserName(token);
        return  (userName.equals(userDetails.getUsername())&& !isTokenExpired(token));

    }
    //17

    private boolean isTokenExpired(String token) {
        return extractExpiration(token).before(new Date());
    }

    //18
    private Date extractExpiration(String token) {
        return  extractclaim(token,Claims::getExpiration);
    }


}


