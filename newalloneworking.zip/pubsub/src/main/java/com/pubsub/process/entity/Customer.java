package com.pubsub.process.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.boot.autoconfigure.amqp.RabbitConnectionDetails.Address;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.*;
import lombok.Data;


@Data
@Table(name = "customer")
@Entity
public class Customer{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	@Column(name = "name", length = 100)
	private String name;

	@Column(name = "email", length = 100)
	private String email;

	@Column(name = "dateofbirth")
	private LocalDate dateOfBirth;

	@Column(name = "gender", length = 20)
	private String gender;

	@Column(name = "mobilenumber", length = 20, nullable = false)
	private String mobileNumber;

	@Column(name = "active")
	private Boolean active;

	@Column(name = "createddate")
	private LocalDateTime createdDate;

	@Column(name = "createdby", length = 45)
	private String createdBy;

	@Column(name = "modifieddate")
	@UpdateTimestamp
	private LocalDateTime modifiedDate;

	@Column(name = "modifiedby", length = 45)
	private String modifiedBy;
}
