package com.allin.one.Config;


import com.allin.one.serviceImpl.JWTUserDetailsService;
import com.allin.one.serviceImpl.JwtServiceImpl;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

//4
@Component
// 5 add extends OncePerRequestFilter to this class
public class JwtfilterConfig extends OncePerRequestFilter {

    @Autowired
    ApplicationContext applicationContext;

    @Autowired
    JwtServiceImpl serviceimpl;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        {

            String authheader=request.getHeader("Authorization");
            String username=null;
            String token=null;

            if(authheader!=null && authheader.startsWith("Bearer")){

                token=authheader.substring(7);
                // 12.1 here we ill extract the user name form the token to validate the entered user and token user are same
                username=serviceimpl.extractuserName(token);

            }
            // 13 if the request is already authentiated it will not check again if not it will check

            if(username!=null&& SecurityContextHolder.getContext().getAuthentication()==null){
                // 14 applicationContext we can able to get the bean of any class fro the usedetails service class we have methof to find the user by the user name so we are using that to validate the user
                UserDetails userDetails=applicationContext.getBean(JWTUserDetailsService.class).loadUserByUsername(username);

//15 here will validate the token with user details
                if(serviceimpl.validateToken(token,userDetails)){
                    UsernamePasswordAuthenticationToken authtoken=
                            new UsernamePasswordAuthenticationToken(userDetails,null,userDetails.getAuthorities());
                    authtoken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                    SecurityContextHolder.getContext().setAuthentication(authtoken);
                }
            }
            // 19 once its true will retrun the req and res it will return to securityconfig class and securityFilterChain mthod
            filterChain.doFilter(request,response);

        }
    }
}
