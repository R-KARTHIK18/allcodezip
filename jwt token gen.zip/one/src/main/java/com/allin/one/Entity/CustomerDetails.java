package com.allin.one.Entity;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;


@Entity
@Table(name = "customer_login_data")
@Data
public class CustomerDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private int id;
    private String name;
    private String password;
    private String modifiedby;
    private String createdby;
    private LocalDateTime createddate;
    private LocalDateTime modifieddate;
}
