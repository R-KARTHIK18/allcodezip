package com.allin.one.Controller;


import com.allin.one.Entity.CustomerDetails;
import com.allin.one.serviceImpl.JwtServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class JWTController {


    @Autowired
    JwtServiceImpl jwtService;
    @PostMapping("/signin")
    public CustomerDetails UserSignIn(@RequestBody CustomerDetails user){
        return  jwtService.UserSignIn(user);
    }


//1
    @GetMapping("/generatetoken")
    public  String generateToken(@RequestBody CustomerDetails data){

        return  jwtService.getToken(data);
    }

    @GetMapping("/test")
    public String test(){
        return  "success";
    }

}
