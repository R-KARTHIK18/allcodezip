package com.allin.one.Repository;

import com.allin.one.Entity.CustomerDetails;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CustomerDetailsRepo extends JpaRepository<CustomerDetails ,Integer> {
    CustomerDetails findByName(String username);
}
