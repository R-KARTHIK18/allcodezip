package com.allin.one.serviceImpl;

import com.allin.one.Entity.CustomerDetails;
import com.allin.one.Repository.CustomerDetailsRepo;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

@Service
@Log4j2
public class JwtServiceImpl {
    @Autowired
    CustomerDetailsRepo customerDetailsRepo;

    @Autowired
    AuthenticationManager authmanager;

    private String seckeys="";

    public  JwtServiceImpl(){
        try {
            KeyGenerator ke=KeyGenerator.getInstance("HmacSHA256");
            SecretKey sk=ke.generateKey();
            seckeys= Base64.getEncoder().encodeToString(sk.getEncoded());
        }catch (NoSuchAlgorithmException es){
            log.info(es.getMessage());
        }


    }

    private  BCryptPasswordEncoder encoder=new BCryptPasswordEncoder(12);
    public CustomerDetails UserSignIn(CustomerDetails user) {

        try {
            user.setPassword(encoder.encode(user.getPassword()));
            user.setCreateddate(LocalDateTime.now());
            user.setModifieddate(LocalDateTime.now());

            return customerDetailsRepo.save(user);
        }catch (Exception e){
            log.info(e.getMessage());
        }
        return user;
    }


    public String getToken(CustomerDetails data) {

        try{
            //2 - 3 will move SecurityConfig class
            Authentication auth= authmanager.authenticate(new UsernamePasswordAuthenticationToken(data.getName(),data.getPassword()));
//22 if the user is autheorized will generate the token
            if (auth.isAuthenticated()){
                return generatetoken(data.getName()) ;
            }else {return "fail";

            }}catch (Exception e){
            log.info(e.getMessage());
        }
        return  null;
    }

    private String generatetoken(String name) {
        Map<String,Object> claims=new HashMap<>();

        return Jwts.builder()

                .claims()
                .add(claims).subject(name)
                .issuedAt(new Date(System.currentTimeMillis()))
                .expiration(new Date(System.currentTimeMillis()+60*60*30))
                .and()
                .signWith(getkey()).compact();
    }

    // 12.2
    public String extractuserName(String token) {

        return extractclaim(token, Claims::getSubject);
    }
    // 12.3
    private <T> T extractclaim(String token, Function<Claims,T> claimResolver) {
        final Claims claims=extractAllclaim(token);
        return  claimResolver.apply(claims);
    }
    // 12.4
    private Claims extractAllclaim(String token) {
        return Jwts.parser()
                .verifyWith(getkey())
                .build().parseSignedClaims(token).getPayload();
    }

    private SecretKey getkey() {
        byte[] keysby= Decoders.BASE64.decode(seckeys);
        return Keys.hmacShaKeyFor(keysby);
    }

    public boolean validateToken(String token, UserDetails userDetails) {

        final String userName=extractuserName(token);
        return  (userName.equals(userDetails.getUsername())&& !isTokenExpired(token));

    }
    //17

    private boolean isTokenExpired(String token) {
        return extractExpiration(token).before(new Date());
    }

    //18
    private Date extractExpiration(String token) {
        return  extractclaim(token,Claims::getExpiration);
    }

}
