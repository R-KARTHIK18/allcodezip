package com.allin.one.serviceImpl;


import com.allin.one.Config.userPrincipleClass;
import com.allin.one.Entity.CustomerDetails;
import com.allin.one.Repository.CustomerDetailsRepo;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
@Log4j2
public class JWTUserDetailsService implements UserDetailsService {

    @Autowired
    ObjectMapper mapper;
    @Autowired
    private CustomerDetailsRepo userRepo;



    //8
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        CustomerDetails customer=userRepo.findByName(username);
        if (customer == null) {
            throw new UsernameNotFoundException("User not found");
        }
        log.info("user data found {}",customer.getName());
        // 9 once the user found will retrun the useretails to security config class authenticationProvider method
        return new userPrincipleClass(customer);
    }
}
