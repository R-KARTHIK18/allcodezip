package com.pubsub.process.model;

import lombok.Data;

@Data
public class userData {

	public String name;
	public int id;
}
